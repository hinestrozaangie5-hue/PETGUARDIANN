# PetGuardian — Referencia de la API

API REST en JSON servida por el backend Express bajo el prefijo `/api`.

- **Base de desarrollo:** `http://localhost:3000`
- **En el frontend:** el proxy de Vite redirige `/api` al backend, por lo que el
  cliente usa rutas relativas (`/api/...`).
- **Autenticación:** cookie de sesión `pg_session` (por defecto), `HttpOnly` y
  `SameSite=Lax`. El navegador la envía automáticamente con
  `credentials: "include"`.
- **Formato:** todas las respuestas son `application/json`. Los cuerpos de
  solicitud con datos se envían como JSON (límite `6mb`, por la foto en base64).

---

## 1. Convenciones

### 1.1 Envoltorios de respuesta

Cada recurso se devuelve bajo una clave con su nombre:

| Recurso | Clave |
| --- | --- |
| Mascota(s) | `pet` / `pets` |
| Solicitud(es) de adopción | `adoption` / `adoptions` |
| Evento(s) | `events` |
| Registro(s) clínico(s) | `record` / `records` (+ `type`) |
| Usuario(s) | `user` / `users` |
| Veterinarios | `veterinarians` |
| Roles públicos | `roles` |
| Panel | `dashboard` |

Ejemplo: `GET /api/pets` → `{ "pets": [ ... ] }`.

### 1.2 Errores

Formato uniforme (`middlewares/errorHandler.js`):

```json
{
  "error": "codigo_maquina",
  "message": "Mensaje legible en español.",
  "details": { "campo": "descripción del problema" }
}
```

`details` solo está presente cuando existe (habitualmente en `400`).

### 1.3 Códigos de estado

| Estado | Significado | Códigos típicos |
| --- | --- | --- |
| `200` | OK | lectura/actualización |
| `201` | Creado | alta de recursos |
| `400` | Validación | `validation_error`, `invalid_id` |
| `401` | Sin sesión | `unauthorized`, `invalid_credentials` |
| `403` | Sin permiso | `forbidden` |
| `404` | No encontrado | `pet_not_found`, `adoption_not_found`, `record_not_found`, `medical_type_not_found`, `not_found` |
| `409` | Conflicto | `email_taken`, `possible_duplicate`, `duplicate_request`, `pet_not_available`, `invalid_status_transition`, `procedure_not_completed`, `invalid_performed_date` |
| `500` | Error interno | `internal_error` |

---

## 2. Salud

### `GET /api/health`

Público. Parámetro opcional `verbose`.

- `verbose` ausente o `false` → respuesta resumida.
- `verbose=true` → informe completo.
- Cualquier otro valor → `400`.

**Resumida**

```json
{
  "status": "ok",
  "service": "petguardian-backend",
  "version": "0.1.0",
  "timestamp": "2026-01-01T00:00:00.000Z",
  "database": true
}
```

**Completa** (`?verbose=true`)

```json
{
  "status": "ok",
  "service": "petguardian-backend",
  "version": "0.1.0",
  "timestamp": "2026-01-01T00:00:00.000Z",
  "uptimeSeconds": 12.34,
  "database": { "connected": true, "schemaVersion": "4" }
}
```

`status` es `ok` si la BD responde, o `degraded` en caso contrario.

---

## 3. Autenticación

### `POST /api/auth/register`

Público. Crea una cuenta (no admin) e inicia sesión emitiendo la cookie.

**Cuerpo**

```json
{
  "email": "ana@example.com",
  "password": "contrasena-segura",
  "fullName": "Ana Torres",
  "role": "adoptante"
}
```

**Reglas:** email válido y único; `password` ≥ 8 caracteres; `fullName` ≥ 3;
`role` ∈ `{adoptante, fundacion, veterinario}` (por defecto `adoptante`).

**Respuesta `201`**

```json
{ "user": { "id": 1, "email": "ana@example.com", "fullName": "Ana Torres", "role": "adoptante", "createdAt": "..." } }
```

**Errores:** `400 validation_error` (con `details`), `409 email_taken`.

### `POST /api/auth/login`

Público.

**Cuerpo:** `{ "email": "...", "password": "..." }`

**Respuesta `200`:** `{ "user": { ... } }` + `Set-Cookie: pg_session=...`

**Errores:** `400 validation_error`, `401 invalid_credentials`.

### `POST /api/auth/logout`

Requiere sesión. Invalida el token y limpia la cookie.

**Respuesta `200`:** `{ "ok": true }`

### `GET /api/auth/me`

Requiere sesión.

**Respuesta `200`:** `{ "user": { ... } }`

**Errores:** `401 unauthorized`.

### `GET /api/auth/roles`

Público. Roles disponibles para el registro público.

**Respuesta `200`**

```json
{ "roles": [ { "value": "adoptante", "label": "Adoptante" }, { "value": "fundacion", "label": "Fundacion" }, { "value": "veterinario", "label": "Veterinario aliado" } ] }
```

---

## 4. Usuarios

### `GET /api/users`

Solo `admin`. Lista de usuarios (sin `passwordHash`).

**Respuesta `200`:** `{ "users": [ { "id", "email", "fullName", "role", "createdAt" } ] }`

**Errores:** `401`, `403`.

### `GET /api/users/veterinarians`

Roles `admin`, `fundacion`, `veterinario` (`MEDICAL_READ_ROLES`). Directorio
reducido para asignar veterinario responsable.

**Respuesta `200`:** `{ "veterinarians": [ { "id": 3, "fullName": "Dra. Valentina Rios" } ] }`

> Solo expone `id` y `fullName`, nunca email ni otros datos.

**Errores:** `401`, `403`.

---

## 5. Mascotas

### `GET /api/pets`

Cualquier usuario autenticado. Filtros por query string.

| Parámetro | Valores | Descripción |
| --- | --- | --- |
| `search` | texto (≤ 80) | Búsqueda por nombre (case-insensitive) |
| `species` | `perro`, `gato` | Filtro por especie |
| `status` | `disponible`, `en_proceso`, `adoptada`, `bajo_cuidado` | Filtro por estado |

Orden: más recientes primero (`created_at DESC, id DESC`).

**Respuesta `200`**

```json
{
  "pets": [
    {
      "id": 1, "name": "Luna", "species": "gato", "breed": "Comun europeo",
      "sex": "hembra", "birthDate": "2021-05-10", "approximateAgeMonths": null,
      "ageMonths": 55, "ageLabel": "4 años", "weightKg": 3.4, "color": "Atigrado",
      "description": "...", "photoUrl": null, "status": "bajo_cuidado",
      "ownerId": 2, "ownerName": "Fundacion Patitas Demo",
      "createdAt": "2026-...", "updatedAt": "2026-..."
    }
  ]
}
```

**Errores:** `400 validation_error` (filtro inválido), `401`.

> El frontend, para el rol `adoptante`, filtra localmente a `disponible` y
> `en_proceso`; la API no oculta otros estados en el listado.

### `GET /api/pets/:id`

Cualquier autenticado.

**Respuesta `200`:** `{ "pet": { ... } }`
**Errores:** `400 invalid_id`, `404 pet_not_found`, `401`.

### `POST /api/pets`

Roles `admin`, `fundacion` (`PET_WRITE_ROLES`).

**Cuerpo**

```json
{
  "name": "Firulais", "species": "perro", "breed": "Mestizo", "sex": "macho",
  "birthDate": "2022-03-01", "approximateAgeMonths": null, "weightKg": 12.5,
  "color": "Marron", "description": "Muy jugueton.", "status": "disponible",
  "photoUrl": "data:image/png;base64,..."
}
```

- `name`: 2–80 caracteres. `species`: `perro`|`gato`. `sex`: `macho`|`hembra`|`desconocido`.
- `birthDate`: `AAAA-MM-DD`, no futura. `approximateAgeMonths`: entero 0–600.
- `weightKg`: 0.01–200. `status`: estado válido (por defecto `disponible`).
- `photoUrl`: `http(s)://...` (≤ 2048) o data URL `image/png|jpeg|webp`
  (≤ 2 MB, con verificación de bytes mágicos).

**Respuesta `201`:** `{ "pet": { ... } }`
**Errores:** `400 validation_error`, `403 forbidden`, `409 possible_duplicate`.

### `PUT /api/pets/:id`

Dueño o `admin` (`PET_WRITE_ROLES` + propiedad en el servicio). Mismos campos
que el alta. Si se omite `status`, se conserva el actual.

**Respuesta `200`:** `{ "pet": { ... } }`
**Errores:** `400`, `403`, `404`, `409 invalid_status_transition`.

### `DELETE /api/pets/:id`

Dueño o `admin`.

**Respuesta `200`:** `{ "id": 1 }`
**Errores:** `400 invalid_id`, `403`, `404`.

---

## 6. Salud veterinaria (expediente clínico)

Rutas anidadas: `/api/pets/:petId/<tipo>[/:recordId]`.

`type` ∈ `vaccinations`, `procedures`, `appointments`, `consultations`,
`deworming`. Un `type` desconocido responde `404 medical_type_not_found`.

**Acceso:** lectura y escritura para `MEDICAL_READ_ROLES` / `MEDICAL_WRITE_ROLES`
(`admin`, `fundacion`, `veterinario`), con regla de propiedad para `fundacion`.
El `adoptante` recibe `403`. La restricción de lectura también se aplica en el
servicio (no solo por rol de ruta).

### `GET /api/pets/:petId/:type`

**Respuesta `200`:** `{ "type": "vaccinations", "records": [ ... ] }`

Cada registro incluye `id`, `petId`, campos del tipo, `veterinarianId`,
`veterinarianName`, `createdBy`, `createdAt`, `updatedAt` y, cuando aplica,
`status` + `statusLabel` (calculado o almacenado).

### `GET /api/pets/:petId/:type/:recordId`

**Respuesta `200`:** `{ "type": "...", "record": { ... } }`
**Errores:** `400 invalid_id`, `403`, `404 record_not_found`.

### `POST /api/pets/:petId/:type`

**Cuerpo por tipo**

| Tipo | Campos |
| --- | --- |
| `vaccinations` | `vaccineName`\*, `appliedDate`\*, `nextDoseDate`, `veterinarianId`, `batchNumber`, `notes` |
| `deworming` | `productName`\*, `dewormingType` (`interna`/`externa`/`mixta`), `appliedDate`\*, `nextDoseDate`, `veterinarianId`, `notes` |
| `procedures` | `procedureType`\*, `status` (`pendiente`/`programado`/`realizado`/`cancelado`), `scheduledDate`, `performedDate`, `veterinarianId`, `notes` |
| `appointments` | `reason`\*, `scheduledAt`\* (`AAAA-MM-DD HH:MM`), `status` (`programada`/`completada`/`cancelada`), `veterinarianId`, `notes` |
| `consultations` | `reason`\*, `consultationDate`\*, `diagnosis`, `treatment`, `veterinarianId`, `notes` |

`*` = obligatorio. Fechas de aplicación/consulta (`appliedDate`,
`consultationDate`) **no** pueden ser futuras. `veterinarianId`, si se indica,
debe existir (`400`).

**Respuesta `201`:** `{ "type": "...", "record": { ... } }`

### `PUT /api/pets/:petId/:type/:recordId`

Actualización parcial: solo se modifican los campos enviados. Para
`procedures` aplica validación de transición e integridad.

**Respuesta `200`:** `{ "type": "...", "record": { ... } }`
**Errores:** `400`, `403`, `404`, `409 invalid_status_transition`,
`409 procedure_not_completed`, `409 invalid_performed_date`.

### `DELETE /api/pets/:petId/:type/:recordId`

**Respuesta `200`:** `{ "id": 17 }`
**Errores:** `400`, `403`, `404`.

---

## 7. Adopciones

### `GET /api/adoptions`

Roles `admin`, `fundacion`, `adoptante` (`ADOPTION_READ_ROLES`). El `veterinario`
recibe `403`. El alcance depende del rol:

- `adoptante` → solo sus solicitudes (`applicant_id`).
- `fundacion` → solo solicitudes de sus mascotas (`pets.owner_id`).
- `admin` → todas.

| Parámetro | Valores |
| --- | --- |
| `status` | `pendiente`, `aprobada`, `rechazada`, `cancelada` |
| `petId` | entero > 0 |

**Respuesta `200`:** `{ "adoptions": [ { ... } ] }`

### `POST /api/adoptions`

Solo `adoptante`. La mascota no puede estar `adoptada` y no puede existir otra
solicitud pendiente del mismo solicitante para esa mascota.

**Cuerpo:** `{ "petId": 4, "message": "Vivo en un piso con patio..." }`
(`message` ≤ 500, opcional).

**Respuesta `201`:** `{ "adoption": { ... } }` con `status: "pendiente"`. Si la
mascota estaba `disponible`, pasa a `en_proceso`.

**Errores:** `400 validation_error`, `403`, `404 pet_not_found`,
`409 pet_not_available`, `409 duplicate_request`.

### `GET /api/adoptions/:id`

Solicitante, fundación dueña o `admin`.

**Respuesta `200`:** `{ "adoption": { ... } }`
**Errores:** `400`, `403`, `404 adoption_not_found`.

### `GET /api/adoptions/:id/events`

Mismo acceso. Historial (`created`, `edited`, `approved`, `rejected`,
`cancelled`).

**Respuesta `200`:** `{ "events": [ { "id", "type", "typeLabel", "fromStatus", "fromStatusLabel", "toStatus", "toStatusLabel", "actorId", "actorName", "note", "createdAt" } ] }`

### `PUT /api/adoptions/:id`

Solicitante o `admin`, solo si la solicitud está `pendiente`. Edita
`message`.

**Cuerpo:** `{ "message": "..." }`
**Respuesta `200`:** `{ "adoption": { ... } }`
**Errores:** `400`, `403`, `409 invalid_status_transition` (no pendiente).

### `POST /api/adoptions/:id/approve`

Fundación dueña o `admin` (`ADOPTION_DECISION_ROLES` + propiedad). Transacción
`BEGIN IMMEDIATE`.

**Cuerpo:** `{ "note": "..." }` (opcional, ≤ 500).

**Respuesta `200`:** `{ "adoption": { ... status: "aprobada" } }`. La mascota
pasa a `adoptada` y las demás pendientes se rechazan automáticamente.

**Errores:** `403`, `404`, `409 pet_not_available`, `409 invalid_status_transition`.

### `POST /api/adoptions/:id/reject`

Fundación dueña o `admin`.

**Cuerpo:** `{ "note": "..." }` (opcional).

**Respuesta `200`:** `{ "adoption": { ... status: "rechazada" } }`. Libera la
mascota a `disponible` si corresponde.

### `POST /api/adoptions/:id/cancel`

Solicitante o `admin`, solo si `pendiente`.

**Respuesta `200`:** `{ "adoption": { ... status: "cancelada" } }`. Libera la
mascota a `disponible` si corresponde.

**Errores transversales de decisión:** `403`, `404`, `409 invalid_status_transition`.

---

## 8. Panel

### `GET /api/dashboard`

Cualquier usuario autenticado. El contenido depende del rol.

**Respuesta `200`**

```json
{
  "dashboard": {
    "pets": {
      "total": 6, "perros": 3, "gatos": 3,
      "disponibles": 3, "enProceso": 1, "adoptadas": 1, "bajoCuidado": 1
    },
    "adoptions": { "pendientes": 1, "aprobadas": 0, "total": 1 },
    "medical": {
      "vacunasProximas": 1, "vacunasVencidas": 1,
      "desparasitacionesProximas": 1, "desparasitacionesVencidas": 1,
      "cirugiasPendientes": 2, "proximasCitas": 3
    },
    "attention": [
      {
        "id": 1, "name": "Luna", "species": "gato", "photoUrl": null,
        "status": "bajo_cuidado",
        "vacunasVencidas": 1, "vacunasProximas": 1,
        "desparasitacionesVencidas": 1, "desparasitacionesProximas": 1,
        "cirugiasPendientes": 1, "citasProximas": 1,
        "proximaFecha": "2026-...", "vencidaFecha": "2026-..."
      }
    ]
  }
}
```

**Presencia de secciones por rol**

| Sección | admin | fundacion | veterinario | adoptante |
| --- | :---: | :---: | :---: | :---: |
| `pets` | ✅ (global) | ✅ (propias) | ✅ (global) | ✅ (global) |
| `adoptions` | ✅ (global) | ✅ (propias) | — | ✅ (propias) |
| `medical` + `attention` | ✅ | ✅ (propias) | ✅ | — |

`attention` se limita a **6** mascotas y solo incluye las que tienen al menos una
alerta.

---

## 9. Resumen de rutas

| Método | Ruta | Acceso |
| --- | --- | --- |
| GET | `/api/health` | Público |
| POST | `/api/auth/register` | Público |
| POST | `/api/auth/login` | Público |
| POST | `/api/auth/logout` | Autenticado |
| GET | `/api/auth/me` | Autenticado |
| GET | `/api/auth/roles` | Público |
| GET | `/api/users` | admin |
| GET | `/api/users/veterinarians` | admin, fundacion, veterinario |
| GET | `/api/dashboard` | Autenticado |
| GET | `/api/pets` | Autenticado |
| GET | `/api/pets/:id` | Autenticado |
| POST | `/api/pets` | admin, fundacion |
| PUT | `/api/pets/:id` | dueño o admin |
| DELETE | `/api/pets/:id` | dueño o admin |
| GET | `/api/pets/:petId/:type` | admin, fundacion (propias), veterinario |
| GET | `/api/pets/:petId/:type/:recordId` | admin, fundacion (propias), veterinario |
| POST | `/api/pets/:petId/:type` | admin, fundacion (propias), veterinario |
| PUT | `/api/pets/:petId/:type/:recordId` | admin, fundacion (propias), veterinario |
| DELETE | `/api/pets/:petId/:type/:recordId` | admin, fundacion (propias), veterinario |
| GET | `/api/adoptions` | admin, fundacion, adoptante |
| POST | `/api/adoptions` | adoptante |
| GET | `/api/adoptions/:id` | solicitante, fundación dueña, admin |
| GET | `/api/adoptions/:id/events` | solicitante, fundación dueña, admin |
| PUT | `/api/adoptions/:id` | solicitante, admin (pendiente) |
| POST | `/api/adoptions/:id/approve` | fundación dueña, admin |
| POST | `/api/adoptions/:id/reject` | fundación dueña, admin |
| POST | `/api/adoptions/:id/cancel` | solicitante, admin |

---

## 10. Ejemplos con `curl` / PowerShell

```powershell
# Estado del servicio (informe completo)
Invoke-RestMethod "http://localhost:3000/api/health?verbose=true"

# Login y guardado de cookie de sesión
$session = New-Object Microsoft.PowerShell.Commands.WebRequestSession
Invoke-RestMethod -Method Post -Uri "http://localhost:3000/api/auth/login" `
  -ContentType "application/json" -WebSession $session `
  -Body '{"email":"demo.admin@petguardian.test","password":"demo-password-123"}'

# Listar mascotas
Invoke-RestMethod -Uri "http://localhost:3000/api/pets" -WebSession $session

# Panel
Invoke-RestMethod -Uri "http://localhost:3000/api/dashboard" -WebSession $session
```
